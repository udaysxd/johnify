# slidegen.py
import re, json
from pathlib import Path
from markdown2 import markdown
from bs4 import BeautifulSoup
import shutil
from openai import OpenAI
from typing import List, Dict, Tuple, Optional, Union
import time
import hashlib
import os
from pathlib import Path
import requests
import concurrent.futures
import asyncio

# Initialize DeepSeek client
client = OpenAI(
    base_url="https://api.deepseek.com/v1",
    api_key=os.environ.get("DEEPSEEK_API_KEY")
)

if not client.api_key:
    print("⚠️ Warning: DEEPSEEK_API_KEY environment variable not set. Slide content generation will fail.")

# Configuration for Pollinations AI
POLLINATIONS_BASE_URL = "https://image.pollinations.ai/prompt/"
CACHE_DIR = Path("./image_cache")
CACHE_DIR.mkdir(exist_ok=True)

# ─── helpers ────────────────────────────────────────────────────────
def markdown_to_plain_text(md: str) -> str:
    return BeautifulSoup(markdown(md), "html.parser")\
        .get_text(separator=" ", strip=True)

def fresh_dir(path: str):
    p = Path(path)
    if p.exists():
        shutil.rmtree(p)
    p.mkdir(parents=True, exist_ok=True)
    return p

def clean_markdown_text(text: str) -> str:
    """Clean and escape markdown text to prevent formatting issues."""
    if not text:
        return ""
    # Escape special markdown characters
    text = str(text)
    # First escape backslashes
    text = text.replace('\\', '\\\\')
    # Then escape other special characters
    for char in '`*_{}[]()#+-.!|':
        text = text.replace(char, f'\\{char}')
    return text

async def process_question_async(question_data: dict) -> List[str]:
    """Process a single question and generate its slides asynchronously."""
    question = clean_markdown_text(question_data.get('question', 'Question'))
    correct_answer = clean_markdown_text(question_data.get('correct_answer', 'No answer'))
    explanation = clean_markdown_text(question_data.get('explanation', 'No explanation available'))
    
    # Generate slides for this question
    return generate_concept_slides(question, correct_answer, explanation)

def extract_key_points(explanation: str) -> List[str]:
    """Extract key points from the explanation text."""
    # Split the explanation into sentences
    sentences = [s.strip() for s in re.split(r'(?<=[.!?])\s+', explanation) if s.strip()]
    
    # Take the most important sentences (first few and last one)
    key_points = []
    if len(sentences) >= 1:
        key_points.append(sentences[0])  # First sentence is usually the main point
    if len(sentences) >= 3:
        key_points.append(sentences[1])  # Second sentence often contains important info
    if len(sentences) >= 2:
        key_points.append(sentences[-1])  # Last sentence often summarizes
    
    # Ensure we have at least 3 points
    while len(key_points) < 3:
        key_points.append("This concept is fundamental to understanding the topic.")
    
    return key_points[:3]  # Return max 3 key points

def generate_example_steps(question: str, answer: str) -> List[str]:
    """Generate example steps based on the question and answer."""
    steps = []
    
    # Step 1: Restate the question in a learning context
    steps.append(f"Let's analyze the question: {question}")
    
    # Step 2: Break down the correct answer
    steps.append(f"The correct answer is: {answer}")
    
    # Step 3: Provide context or application
    steps.append("This demonstrates an important concept in the subject area.")
    
    return steps

def generate_concept_slides(question: str, correct_answer: str, explanation: str) -> List[str]:
    """
    Generate detailed slides for a single concept with up to 5 slides.
    Uses simplified prompts for better reliability.
    """
    slides = []
    concept = question.split('?')[0].strip() if '?' in question else question.strip()
    
    # Generate a simple concept name for image prompts
    concept_words = [w for w in concept.lower().split() if len(w) > 3][:2]
    concept_name = ' '.join(concept_words) if concept_words else 'learning concept'
    
    # Extract key points from the explanation
    key_points = extract_key_points(explanation)
    
    # Generate example steps
    example_steps = generate_example_steps(question, correct_answer)
    
    # Slide 1: Concept Introduction
    slide1 = f"## Understanding: {concept}\n\n"
    slide1 += f"![{concept}]({get_image_url(concept_name, 800, 300)})\n\n"
    slide1 += f"**Question:** {question}\n\n"
    slide1 += f"**Correct Answer:** {correct_answer}"
    slides.append(slide1)
    
    # Slide 2: Core Concept Explanation
    slide2 = f"## {concept}: Core Concept\n\n"
    slide2 += f"![{concept} Concept]({get_image_url(f'{concept_name} concept', 800, 300)})\n\n"
    slide2 += f"{explanation}\n\n"
    slide2 += "*Key points to remember:*\n"
    for i, point in enumerate(key_points, 1):
        slide2 += f"- {point}\n"
    slides.append(slide2)
    
    # Slide 3: Example Scenario
    slide3 = f"## {concept}: Example\n\n"
    slide3 += f"![{concept} Example]({get_image_url(f'example {concept_name}', 800, 300)})\n\n"
    slide3 += "**Let's break this down:**\n\n"
    for i, step in enumerate(example_steps, 1):
        slide3 += f"{i}. {step}\n"
    slides.append(slide3)
    
    # Slide 4: Common Misconceptions
    slide4 = f"## {concept}: Common Pitfalls\n\n"
    slide4 += f"![Common Mistakes]({get_image_url(f'mistakes {concept_name}', 800, 300)})\n\n"
    slide4 += "**Things to watch out for:**\n\n"
    slide4 += f"- Misinterpreting the question: {question.split('?')[0]}?\n"
    slide4 += f"- Confusing {correct_answer} with other similar concepts\n"
    slide4 += "- Overcomplicating the answer - sometimes the most straightforward answer is correct"
    slides.append(slide4)
    
    # Slide 5: Summary and Practice
    slide5 = f"## {concept}: Summary\n\n"
    slide5 += f"![Summary]({get_image_url(f'summary {concept_name}', 800, 300)})\n\n"
    slide5 += "**Key Takeaways:**\n\n"
    for i, point in enumerate(key_points, 1):
        slide5 += f"- {point}\n"
    slide5 += "\n**Try it yourself:**\n"
    slide5 += f"Think of another example where {concept_name.split(' ')[0]} applies in a different context."
    slides.append(slide5)
    
    return slides

def generate_slide_markdown(wrong_questions: List[dict]) -> List[str]:
    """
    Generate detailed learning slides for wrong questions with comprehensive explanations.
    Uses parallel processing for better performance.
    
    Args:
        wrong_questions: List of dictionaries containing wrong questions and answers
        
    Returns:
        List of markdown slide strings
    """
    try:
        if not wrong_questions:
            return []
            
        slides = []
        
        # Add a title slide
        title_slide = (
            "---\n"
            "marp: true\n"
            "theme: default\n"
            "paginate: true\n"
            "---\n\n"
            "# Learning Materials\n\n"
            "Comprehensive review of key concepts based on your quiz results\n"
            "---\n"
        )
        slides.append(title_slide)
        
        # Process questions in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            # Create a future for each question
            future_to_question = {
                executor.submit(
                    asyncio.run, 
                    process_question_async(question)
                ): question for question in wrong_questions
            }
            
            # Process completed futures as they complete
            for future in concurrent.futures.as_completed(future_to_question):
                try:
                    question_slides = future.result()
                    slides.extend(question_slides)
                except Exception as e:
                    print(f"Error processing question: {e}")
                    # Continue with other questions even if one fails
        
        return slides
        
    except Exception as e:
        print(f"Error in generate_slide_markdown: {e}")
        raise

# Update the get_image_url function to use a session for better performance
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Create a session with retry logic
session = requests.Session()
retry_strategy = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[429, 500, 502, 503, 504],
    allowed_methods=["GET"]
)
adapter = HTTPAdapter(max_retries=retry_strategy)
session.mount("https://", adapter)

def get_image_url(prompt: str, width: int = 800, height: int = 300) -> str:
    """
    Generate an image using Pollinations AI with caching.
    Returns a URL to the generated image or a placeholder if generation fails.
    """
    # Simplify and clean the prompt
    prompt = prompt.lower()
    prompt = re.sub(r'[^\w\s-]', ' ', prompt)  # Remove special chars
    words = [w for w in prompt.split() if len(w) > 3][:3]  # Get up to 3 meaningful words
    if not words:
        words = ['education', 'learning', 'concept']
    
    # Create a simple, reliable prompt
    simple_prompt = ' '.join(words) + ' educational'
    simple_prompt = simple_prompt[:50]  # Keep it short and sweet
    
    # Create a unique cache key
    cache_key = hashlib.md5(simple_prompt.encode()).hexdigest()
    cache_file = CACHE_DIR / f"{cache_key}.jpg"
    
    # Return cached image if it exists and is not empty
    if cache_file.exists() and cache_file.stat().st_size > 0:
        return f"https://picsum.photos/seed/{cache_key}/{width}/{height}"
    
    try:
        # Try to generate a new image (using the session for better performance)
        encoded_prompt = requests.utils.quote(simple_prompt)
        image_url = f"https://image.pollinations.ai/prompt/{encoded_prompt}"
        
        response = session.get(image_url, timeout=10)  # Using the session here
        response.raise_for_status()
        
        # Save the image to cache
        with open(cache_file, 'wb') as f:
            f.write(response.content)
            
        return f"https://picsum.photos/seed/{cache_key}/{width}/{height}"
        
    except Exception as e:
        print(f"Error generating image: {e}")
        # Fallback to a placeholder with a unique URL based on the prompt
        return f"https://picsum.photos/seed/{cache_key}/{width}/{height}"

def save_slides_to_md(slides: List[str], output_path: str) -> None:
    """
    Save slides to a markdown file with proper Marp frontmatter and separators.
    """
    frontmatter = (
        "---\n"
        "marp: true\n"
        "theme: default\n"
        "paginate: true\n"
        "---\n\n"
    )

    slide_blocks = []
    for slide in slides:
        slide_clean = slide.strip()
        if not slide_clean:
            continue
        # Ensure each slide is separated properly
        slide_blocks.append(slide_clean)

    full_md = frontmatter + "\n\n---\n\n".join(slide_blocks) + "\n"

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(full_md)

    print(f"✅ Saved {len(slide_blocks)} slides to: {output_path}")


def remove_marp_headers_and_styles(md: str) -> str:
    """
    Fully remove Marp frontmatter, style blocks, and code blocks from a Markdown string.
    """
    # Remove Marp frontmatter blocks
    md = re.sub(r'(?m)^---\s*\n(?:.*?\n)*?^---\s*', '', md)

    # Remove style: | YAML blocks
    md = re.sub(r'(?m)^style:\s*\|(?:\n\s+.*)+', '', md, flags=re.IGNORECASE)

    # Remove HTML <style> blocks
    md = re.sub(r'<style[\s\S]*?</style>', '', md, flags=re.IGNORECASE)

    # Remove Markdown code blocks
    md = re.sub(r'```[\s\S]*?```', '', md)

    # Trim whitespace
    return md.strip()



def generate_learn_slides(topic: str, complexity_level: int = 3) -> List[str]:
    """
    Generate educational slides for a given topic.
    
    Args:
        topic: The topic to generate slides about
        complexity_level: Integer from 1 (basic) to 5 (advanced)
        
    Returns:
        List of slide markdown strings
    """
    try:
        # Define complexity-based parameters
        complexity_map = {
            1: "basic, easy-to-understand",
            2: "introductory, clear",
            3: "intermediate, detailed",
            4: "advanced, comprehensive",
            5: "expert-level, in-depth"
        }
        complexity_desc = complexity_map.get(complexity_level, "detailed")
        
        # Generate slide content using DeepSeek
        def generate_slide_content(prompt: str, min_bullets: int = 2) -> str:
            """Helper function to generate content for a single slide."""
            try:
                # Add explicit formatting instructions
                prompt = f"""{prompt}
                
                FORMATTING RULES:
                - Each main point must start with a '- ' (dash and space)
                - Include 2-4 bullet points per slide
                - Each bullet point should be 1-2 short sentences
                - Use **bold** for emphasis on key terms
                - Keep language clear and concise
                - Never use placeholders like 'key concept 1'
                - Ensure all bullet points are properly formatted with '- ' at the start
                
                Example of good formatting:
                - First main point with a brief explanation
                - Second point that expands on the topic
                - Final point that summarizes or provides context
                
                Now generate content following these rules:
                """
                
                response = client.chat.completions.create(
                    model="deepseek-chat",
                    messages=[
                        {"role": "system", "content": f"You are an expert educational content creator. Generate clear, engaging content for educational slides about {topic} at a {complexity_desc} level."},
                        {"role": "user", "content": prompt}
                    ],
                    temperature=0.7,
                    max_tokens=500
                )
                
                content = response.choices[0].message.content.strip()
                
                # Ensure we have proper bullet points
                lines = [line.strip() for line in content.split('\n') if line.strip()]
                bullet_points = [line for line in lines if line.startswith('-')]
                
                # If we don't have enough bullet points, generate more
                if len(bullet_points) < min_bullets:
                    additional_prompt = f"""
                    The previous response didn't have enough bullet points. 
                    Please provide {min_bullets} more bullet points about: {topic}
                    
                    Format each point with '- ' at the start.
                    """
                    additional_response = client.chat.completions.create(
                        model="deepseek-chat",
                        messages=[
                            {"role": "system", "content": f"You are an expert educational content creator."},
                            {"role": "user", "content": additional_prompt}
                        ],
                        temperature=0.7,
                        max_tokens=300
                    )
                    additional_content = additional_response.choices[0].message.content.strip()
                    additional_bullets = [line for line in additional_content.split('\n') 
                                        if line.strip().startswith('-')]
                    bullet_points.extend(additional_bullets[:min_bullets - len(bullet_points)])
                
                return '\n'.join(bullet_points[:4])  # Return max 4 bullet points
                
            except Exception as e:
                print(f"⚠️ Error generating slide content: {str(e)}")
                # Return default bullet points if generation fails
                return """- Important point about the topic
- Key concept to remember
- Additional relevant information"""
        
        # Generate each slide with specific content
        slides = []
        
        # Slide 1: Introduction
        intro_prompt = f"""
        Create an introduction slide about: {topic}
        
        Include 3 specific bullet points that:
        1. Clearly explain what {topic} is
        2. State why it's important or relevant
        3. Provide an interesting fact or statistic
        
        Format as markdown bullet points with '- ' at the start of each line.
        """
        intro_content = generate_slide_content(intro_prompt, min_bullets=3)
        # Ensure we have at least 3 bullet points
        bullet_points = [line for line in intro_content.split('\n') if line.strip().startswith('-')]
        if len(bullet_points) < 3:
            bullet_points.extend([
                f"- Important aspect of {topic}",
                f"- Why {topic} matters in daily life",
                f"- Key consideration about {topic}"
            ][:3 - len(bullet_points)])
        slides.append(f"## Introduction to {topic}\n" + '\n'.join(bullet_points[:3]))
        
        # Slide 2: Key Concepts
        concepts_prompt = f"""
        List 3 key concepts about: {topic}
        
        For each concept, provide one clear, specific bullet point that:
        1. Names the concept
        2. Explains it simply
        3. Says why it matters
        
        Format as markdown bullet points with '- ' at the start of each line.
        """
        concepts_content = generate_slide_content(concepts_prompt, min_bullets=3)
        bullet_points = [line for line in concepts_content.split('\n') if line.strip().startswith('-')]
        if len(bullet_points) < 3:
            bullet_points.extend([
                f"- Key concept 1 about {topic} and its significance",
                f"- Important aspect of {topic} and its impact",
                f"- Critical consideration regarding {topic}"
            ][:3 - len(bullet_points)])
        slides.append(f"## Key Concepts About {topic}\n" + '\n'.join(bullet_points[:3]))
        
        # Slide 3: How It Works
        process_prompt = f"""
        Explain how {topic} works in 3 simple, specific steps.
        
        For each step, provide one clear bullet point that:
        1. Names the step
        2. Explains what happens
        3. Why it's important
        
        Format as markdown bullet points with '- ' at the start of each line.
        """
        process_content = generate_slide_content(process_prompt, min_bullets=3)
        bullet_points = [line for line in process_content.split('\n') if line.strip().startswith('-')]
        if len(bullet_points) < 3:
            bullet_points.extend([
                f"- Step 1: Initial process of {topic}",
                f"- Step 2: Key mechanisms in {topic}",
                f"- Step 3: Final outcomes of {topic}"
            ][:3 - len(bullet_points)])
        slides.append(f"## How {topic} Works\n" + '\n'.join(bullet_points[:3]))
        
        # Slide 4: Examples
        examples_prompt = f"""
        Provide 3 specific, real-world examples of {topic}.
        
        For each example, include one bullet point that:
        1. Names the example
        2. Briefly describes it
        3. Explains its relevance
        
        Format as markdown bullet points with '- ' at the start of each line.
        """
        examples_content = generate_slide_content(examples_prompt, min_bullets=3)
        bullet_points = [line for line in examples_content.split('\n') if line.strip().startswith('-')]
        if len(bullet_points) < 3:
            bullet_points.extend([
                f"- Example 1: Real-world case of {topic}",
                f"- Example 2: Common situation involving {topic}",
                f"- Example 3: Well-known instance of {topic}"
            ][:3 - len(bullet_points)])
        slides.append(f"## Examples of {topic}\n" + '\n'.join(bullet_points[:3]))
        
        # Slide 5: Summary
        summary_prompt = f"""
        Create a summary about {topic} with 3 key takeaways.
        
        For each takeaway, provide one bullet point that:
        1. States an important fact
        2. Explains its significance
        3. Suggests why it matters
        
        Format as markdown bullet points with '- ' at the start of each line.
        """
        summary_content = generate_slide_content(summary_prompt, min_bullets=3)
        bullet_points = [line for line in summary_content.split('\n') if line.strip().startswith('-')]
        if len(bullet_points) < 3:
            bullet_points.extend([
                f"- Key takeaway 1 about {topic}",
                f"- Important consideration about {topic}",
                f"- Final thought on {topic}"
            ][:3 - len(bullet_points)])
        slides.append(f"## Summary: {topic}\n" + '\n'.join(bullet_points[:3]))
        
        # Clean up any remaining placeholders
        cleaned_slides = []
        for slide in slides:
            # Remove any lines containing placeholders
            lines = [line for line in slide.split('\n') 
                    if not any(ph in line.lower() for ph in ['key concept', 'reason ', 'example ', 'step ', 'point '])]
            cleaned_slide = '\n'.join(lines)
            cleaned_slides.append(cleaned_slide)
        
        return cleaned_slides
        
        
    except Exception as e:
        print(f"Error generating slides: {str(e)}")
        # Return default slides in case of error
        return [
            f"# {topic}\n## Introduction",
            f"## What is {topic}?\n- Key concept 1\n- Key concept 2",
            f"## Why is {topic} important?\n- Reason 1\n- Reason 2"
        ]

def generate_narration(slides: list[str]) -> list[str]:
    """Generate narration for each slide."""
    try:
        global client  # Use the client defined at the module level
        
        # Check if client is properly initialized
        if not client or not hasattr(client, 'chat'):
            raise ValueError("OpenAI client is not properly initialized. Please check your API key.")
            
        MODEL = "deepseek-chat"  # Model to use for narration
        
        narration_prompt = (
            f"There are {len(slides)} slides below. Each starts with a heading.\n\n"
            + "\n\n".join(f"--- SLIDE {i+1} ---\n{slide}" for i, slide in enumerate(slides))
            + "\n\nWrite exactly one engaging GCSE-level narration per slide, 60–90 words each. "
              "Return a valid **JSON array** of narration strings — no extra text, only the array. "
              "Example format: [\"Narration for slide 1\", \"Narration for slide 2\", …]."
        )

        print("Generating narration script …")
        narration_raw = client.chat.completions.create(
            model=MODEL,
            messages=[{"role": "user", "content": narration_prompt}],
            temperature=0.7,
        ).choices[0].message.content.strip()

        # 🔧 Remove Markdown code block if present
        if narration_raw.startswith("```json"):
            narration_raw = narration_raw.removeprefix("```json").removesuffix("```").strip()
        elif narration_raw.startswith("```"):
            narration_raw = narration_raw.removeprefix("```").removesuffix("```").strip()
        
        try:
            narrations = json.loads(narration_raw)
        except json.JSONDecodeError as e:
            print(f"⚠️ DeepSeek raw response (not JSON):\n", narration_raw)
            raise RuntimeError("DeepSeek did not return valid JSON") from e
        
        if not isinstance(narrations, list):
            raise RuntimeError("Expected a JSON array of narration strings.")
        
        if len(narrations) != len(slides):
            print(f"⚠️ JSON returned fewer narrations than slides")
            print(f"📝 JSON array:\n", narrations)
            raise RuntimeError(f"Expected {len(slides)} narrations, got {len(narrations)}")

        return narrations

    except Exception as e:
        print(f"Error generating narration: {str(e)}")
        raise
